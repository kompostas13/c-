﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Pc : Form
    {
        public Pc()
        {
            InitializeComponent();
        }

        private void eshop_DoubleClick(object sender, EventArgs e)
        {
            Eshop eshop1 = new Eshop();
            eshop1.ShowDialog();
        }

        private void exit_button_DoubleClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("DOUBLE CLICK ESHOP ICON TO ENTER THE ESHOP" + Environment.NewLine + "DOUBLE CLICK BOTTOM RIGHT BUTTON TO EXIT");
        }
    }
}
