﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Cafe : Form
    {
        public Cafe()
        {
            InitializeComponent();
        }
        public int sum = 0;

        private void order_label_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            pay_label.Text = "SUM:" + sum.ToString() + "$";
        }

        private void hot_button_Click(object sender, EventArgs e)
        {
            sum += 2;
            pay_label.Text = "SUM:" + sum.ToString() + "$";
        }

        private void cold_button_Click(object sender, EventArgs e)
        {
            sum += 2;
            pay_label.Text = "SUM:" + sum.ToString() + "$";
        }

        private void juice_button_Click(object sender, EventArgs e)
        {
            sum += 2;
            pay_label.Text = "SUM:" + sum.ToString() + "$";
        }

        private void water_button_Click(object sender, EventArgs e)
        {
            sum += 1;
            pay_label.Text = "SUM:" + sum.ToString() + "$";
        }

        private void pay_button_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("PRESS 'ORDER HERE' TO SELECT FROM THE PRODUCTS" + Environment.NewLine + "WHEN YOU COMPLETE YOUR ORDER PRESS PAY" + Environment.NewLine + "PRESS BOTTOM RIGHT BUTTON TO EXIT");
        }
    }
}
