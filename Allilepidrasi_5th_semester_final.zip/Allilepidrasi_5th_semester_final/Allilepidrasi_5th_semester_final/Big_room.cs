﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Big_room : Form
    {
        public Big_room()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void office_button_Click(object sender, EventArgs e)
        {
            Office office1 = new Office();
            office1.ShowDialog();
        }
    }
}
