﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Pc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pc));
            this.eshop_button = new System.Windows.Forms.PictureBox();
            this.eshop_label = new System.Windows.Forms.Label();
            this.exit_button = new System.Windows.Forms.PictureBox();
            this.exit_label = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hELPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.eshop_button)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_button)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // eshop_button
            // 
            this.eshop_button.BackColor = System.Drawing.Color.Transparent;
            this.eshop_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("eshop_button.BackgroundImage")));
            this.eshop_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.eshop_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.eshop_button.Location = new System.Drawing.Point(12, 60);
            this.eshop_button.Name = "eshop_button";
            this.eshop_button.Size = new System.Drawing.Size(55, 52);
            this.eshop_button.TabIndex = 0;
            this.eshop_button.TabStop = false;
            this.eshop_button.DoubleClick += new System.EventHandler(this.eshop_DoubleClick);
            // 
            // eshop_label
            // 
            this.eshop_label.AutoSize = true;
            this.eshop_label.BackColor = System.Drawing.Color.Transparent;
            this.eshop_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eshop_label.Location = new System.Drawing.Point(12, 115);
            this.eshop_label.Name = "eshop_label";
            this.eshop_label.Size = new System.Drawing.Size(55, 20);
            this.eshop_label.TabIndex = 1;
            this.eshop_label.Text = "Eshop";
            this.eshop_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Transparent;
            this.exit_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exit_button.BackgroundImage")));
            this.exit_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exit_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit_button.Location = new System.Drawing.Point(1163, 638);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(43, 47);
            this.exit_button.TabIndex = 2;
            this.exit_button.TabStop = false;
            this.exit_button.DoubleClick += new System.EventHandler(this.exit_button_DoubleClick);
            // 
            // exit_label
            // 
            this.exit_label.AutoSize = true;
            this.exit_label.BackColor = System.Drawing.Color.Transparent;
            this.exit_label.Enabled = false;
            this.exit_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_label.Location = new System.Drawing.Point(1165, 688);
            this.exit_label.Name = "exit_label";
            this.exit_label.Size = new System.Drawing.Size(41, 24);
            this.exit_label.TabIndex = 3;
            this.exit_label.Text = "Exit";
            this.exit_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hELPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1218, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hELPToolStripMenuItem
            // 
            this.hELPToolStripMenuItem.Name = "hELPToolStripMenuItem";
            this.hELPToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.hELPToolStripMenuItem.Text = "HELP";
            this.hELPToolStripMenuItem.Click += new System.EventHandler(this.hELPToolStripMenuItem_Click);
            // 
            // Pc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1218, 730);
            this.Controls.Add(this.exit_label);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.eshop_label);
            this.Controls.Add(this.eshop_button);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Pc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Pc";
            ((System.ComponentModel.ISupportInitialize)(this.eshop_button)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_button)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox eshop_button;
        private System.Windows.Forms.Label eshop_label;
        private System.Windows.Forms.PictureBox exit_button;
        private System.Windows.Forms.Label exit_label;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hELPToolStripMenuItem;
    }
}