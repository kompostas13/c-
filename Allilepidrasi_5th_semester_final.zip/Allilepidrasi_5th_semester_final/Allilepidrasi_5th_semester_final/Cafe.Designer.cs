﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Cafe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cafe));
            this.order_label = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pay_button = new System.Windows.Forms.Button();
            this.pay_label = new System.Windows.Forms.Label();
            this.water_button = new System.Windows.Forms.Button();
            this.juice_button = new System.Windows.Forms.Button();
            this.cold_button = new System.Windows.Forms.Button();
            this.hot_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hELPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // order_label
            // 
            this.order_label.BackColor = System.Drawing.Color.Transparent;
            this.order_label.Cursor = System.Windows.Forms.Cursors.Hand;
            this.order_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_label.ForeColor = System.Drawing.Color.DarkRed;
            this.order_label.Location = new System.Drawing.Point(32, 291);
            this.order_label.Name = "order_label";
            this.order_label.Size = new System.Drawing.Size(135, 41);
            this.order_label.TabIndex = 0;
            this.order_label.Text = "ORDER HERE";
            this.order_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.order_label.Click += new System.EventHandler(this.order_label_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Peru;
            this.panel1.Controls.Add(this.pay_button);
            this.panel1.Controls.Add(this.pay_label);
            this.panel1.Controls.Add(this.water_button);
            this.panel1.Controls.Add(this.juice_button);
            this.panel1.Controls.Add(this.cold_button);
            this.panel1.Controls.Add(this.hot_button);
            this.panel1.Location = new System.Drawing.Point(364, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 256);
            this.panel1.TabIndex = 1;
            this.panel1.Visible = false;
            // 
            // pay_button
            // 
            this.pay_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pay_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay_button.Location = new System.Drawing.Point(75, 230);
            this.pay_button.Name = "pay_button";
            this.pay_button.Size = new System.Drawing.Size(75, 23);
            this.pay_button.TabIndex = 6;
            this.pay_button.Text = "PAY";
            this.pay_button.UseVisualStyleBackColor = true;
            this.pay_button.Click += new System.EventHandler(this.pay_button_Click);
            // 
            // pay_label
            // 
            this.pay_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay_label.Location = new System.Drawing.Point(3, 204);
            this.pay_label.Name = "pay_label";
            this.pay_label.Size = new System.Drawing.Size(90, 23);
            this.pay_label.TabIndex = 5;
            this.pay_label.Text = "SUM: ";
            // 
            // water_button
            // 
            this.water_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.water_button.Location = new System.Drawing.Point(0, 131);
            this.water_button.Name = "water_button";
            this.water_button.Size = new System.Drawing.Size(75, 38);
            this.water_button.TabIndex = 3;
            this.water_button.Text = "WATER";
            this.water_button.UseVisualStyleBackColor = true;
            this.water_button.Click += new System.EventHandler(this.water_button_Click);
            // 
            // juice_button
            // 
            this.juice_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.juice_button.Location = new System.Drawing.Point(0, 86);
            this.juice_button.Name = "juice_button";
            this.juice_button.Size = new System.Drawing.Size(75, 39);
            this.juice_button.TabIndex = 2;
            this.juice_button.Text = "JUICE";
            this.juice_button.UseVisualStyleBackColor = true;
            this.juice_button.Click += new System.EventHandler(this.juice_button_Click);
            // 
            // cold_button
            // 
            this.cold_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cold_button.Location = new System.Drawing.Point(0, 45);
            this.cold_button.Name = "cold_button";
            this.cold_button.Size = new System.Drawing.Size(75, 35);
            this.cold_button.TabIndex = 1;
            this.cold_button.Text = "COLD COFFEE";
            this.cold_button.UseVisualStyleBackColor = true;
            this.cold_button.Click += new System.EventHandler(this.cold_button_Click);
            // 
            // hot_button
            // 
            this.hot_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.hot_button.Location = new System.Drawing.Point(0, 0);
            this.hot_button.Name = "hot_button";
            this.hot_button.Size = new System.Drawing.Size(75, 39);
            this.hot_button.TabIndex = 0;
            this.hot_button.Text = "HOT COFFEE";
            this.hot_button.UseVisualStyleBackColor = true;
            this.hot_button.Click += new System.EventHandler(this.hot_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.BackColor = System.Drawing.Color.Transparent;
            this.exit_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exit_button.BackgroundImage")));
            this.exit_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Location = new System.Drawing.Point(485, 368);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(75, 82);
            this.exit_button.TabIndex = 2;
            this.exit_button.UseVisualStyleBackColor = false;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hELPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(560, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hELPToolStripMenuItem
            // 
            this.hELPToolStripMenuItem.Name = "hELPToolStripMenuItem";
            this.hELPToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.hELPToolStripMenuItem.Text = "HELP";
            this.hELPToolStripMenuItem.Click += new System.EventHandler(this.hELPToolStripMenuItem_Click);
            // 
            // Cafe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(560, 449);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.order_label);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Cafe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cafe";
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label order_label;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button water_button;
        private System.Windows.Forms.Button juice_button;
        private System.Windows.Forms.Button cold_button;
        private System.Windows.Forms.Button hot_button;
        private System.Windows.Forms.Button pay_button;
        private System.Windows.Forms.Label pay_label;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hELPToolStripMenuItem;
    }
}