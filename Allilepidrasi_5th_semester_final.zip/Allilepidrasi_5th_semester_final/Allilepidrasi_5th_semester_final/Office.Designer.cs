﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Office
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Office));
            this.pc_button = new System.Windows.Forms.Button();
            this.scanner_button = new System.Windows.Forms.Button();
            this.copy_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pc_button
            // 
            this.pc_button.BackColor = System.Drawing.Color.Transparent;
            this.pc_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pc_button.Location = new System.Drawing.Point(434, 432);
            this.pc_button.Name = "pc_button";
            this.pc_button.Size = new System.Drawing.Size(275, 156);
            this.pc_button.TabIndex = 0;
            this.pc_button.UseVisualStyleBackColor = false;
            this.pc_button.Click += new System.EventHandler(this.pc_button_Click);
            // 
            // scanner_button
            // 
            this.scanner_button.BackColor = System.Drawing.Color.Transparent;
            this.scanner_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.scanner_button.Location = new System.Drawing.Point(12, 537);
            this.scanner_button.Name = "scanner_button";
            this.scanner_button.Size = new System.Drawing.Size(298, 203);
            this.scanner_button.TabIndex = 1;
            this.scanner_button.UseVisualStyleBackColor = false;
            this.scanner_button.Click += new System.EventHandler(this.scanner_button_Click);
            // 
            // copy_button
            // 
            this.copy_button.BackColor = System.Drawing.Color.Transparent;
            this.copy_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.copy_button.Location = new System.Drawing.Point(771, 415);
            this.copy_button.Name = "copy_button";
            this.copy_button.Size = new System.Drawing.Size(345, 308);
            this.copy_button.TabIndex = 3;
            this.copy_button.UseVisualStyleBackColor = false;
            this.copy_button.Click += new System.EventHandler(this.copy_button_Click);
            // 
            // Office
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1236, 769);
            this.Controls.Add(this.copy_button);
            this.Controls.Add(this.scanner_button);
            this.Controls.Add(this.pc_button);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Office";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Office_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pc_button;
        private System.Windows.Forms.Button scanner_button;
        private System.Windows.Forms.Button copy_button;
    }
}