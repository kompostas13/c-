﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class SearchForm : Form
    {

        Cart cart;

        public bool flag = false;
        public string sss;
        public SearchForm( string search, Cart c)
        {
            InitializeComponent();
            sss = search;
            search_label.Text = search;
            cart = c;
            flag = true;
        }

        public Cart take_cart()
        {
            if (!flag)
            {
                cart = new Cart();
            }
            return cart;
        }

        private void SearchForm_Load(object sender, EventArgs e)
        {
            
        }

        private void add_to_cart_button_Click(object sender, EventArgs e)
        {
            cart.add_to_cart(sss);
        }
    }
}