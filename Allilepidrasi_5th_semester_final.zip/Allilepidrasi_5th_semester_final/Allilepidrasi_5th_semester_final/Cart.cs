﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Cart : Form
    {
        public Cart()
        {
            InitializeComponent();
        }

        public int sum = 0;
        public int conv;
        public bool f1 = true;
        public bool f2 = true;
        public bool f3 = true;
        public bool f4 = true;
        public bool f5 = true;
        public bool f6 = true;
        public bool f7 = true;
    

        public void add_to_cart(string product)
        {


            if (cart_l1.Text == "YOUR CART IS EMPTY." & f1)
            {
                MessageBox.Show(product);
                cart_l1.Text = product;
                f1 = false;
            }
            else if (cart_l2.Text == "" & f2)
            {
                cart_l2.Text = product;
                f2 = false;
            }
            else if (cart_l3.Text == "" & f3)
            {
                cart_l3.Text = product;
                f3 = false;
            }
            else if (cart_l4.Text == "" & f4)
            {
                cart_l4.Text = product;
                f4 = false;
            }
            else if (cart_l5.Text == "" & f5)
            {
                cart_l5.Text = product;
                f5 = false;
            }
            else if (cart_l6.Text == "" & f6)
            {
                cart_l6.Text = product;
                f6 = false;
            }
            else if (cart_l7.Text == "" & f7)
            {
                cart_l7.Text = product;
                f7 = false;
            }
            else
            {
                MessageBox.Show("YOUR CART IS FULL", "ERROR");
            }
            string lastWord = product.Split(',').Last();
            lastWord = lastWord.Substring(0, lastWord.Length - 3);
            MessageBox.Show(lastWord);
            int.TryParse(lastWord,out conv);
            sum += conv;
            sum_label.Text ="SUM: " + sum.ToString() + " $";
        }

        private void Cart_Load(object sender, EventArgs e)
        {

        }

        private void pay_button_Click(object sender, EventArgs e)
        {


            if (cart_l1.Text != "YOUR CART IS EMPTY." && name_text.Text != "" & card_mask.MaskCompleted && addr_text.Text != "")
            {
                MessageBox.Show("THANK YOU FOR YOUR ORDER!!", "SUCCESS");
                name_text.Text = "";
                addr_text.Text = "";
                card_mask.Text = "";
                cart_l1.Text = "";
                cart_l2.Text = "";
                cart_l3.Text = "";
                cart_l4.Text = "";
                cart_l5.Text = "";
                cart_l6.Text = "";
                cart_l7.Text = "";
                sum = 0;
                sum_label.Text = "SUM: " + sum.ToString() + " $";
                this.Close();
            }
            else
            {
                MessageBox.Show("SOMETHING WENT WRONG!!", "ERROR");
            }
        }

        private void addr_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cart_l1_Click(object sender, EventArgs e)
        {

        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ENTER YOUR FULL NAME / CARD NUMBER / ADDRESS AND PRESS THE PAY PUTTON");
        }
    }
}
