﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Eshop : Form
    {


        
        SearchForm searchf;

        public Cart cart1;
        public Eshop()
        {
            InitializeComponent();
            cart1 = new Cart();
        }


        private void Eshop_Load(object sender, EventArgs e)
        {


            int counter = 0;
            string line;

            System.IO.StreamReader file =
                new System.IO.StreamReader("data.csv");
            while ((line = file.ReadLine()) != null)
            {
                books_label.Text = books_label.Text + "*" + line + Environment.NewLine + Environment.NewLine;
                counter++;
            }
            file.Close();
        }

        private void Search_function(string text)
        {

            string result = "";
            string line;
            bool notfound = true;
            System.IO.StreamReader cont_searcher = new System.IO.StreamReader("data.csv");
            while ((line = cont_searcher.ReadLine()) != null)
            {
                if (text == "")
                {
                    break;
                }
                if (line.Contains(text))
                {
                    result = result + " " +  line + Environment.NewLine;
                    notfound = false;
                    searchf = new SearchForm(result, cart1);
                    searchf.ShowDialog();
                    break;
                }

            }
            if (notfound)
            {
                MessageBox.Show("Nothing matched your search!", "Error");
                books_label.Visible = true;
            }
            cont_searcher.Close();



        }

        private void search_pic_Click(object sender, EventArgs e)
        {
            Search_function(search_text.Text);
            search_text.Text = "";
        }

        private void search_text_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Search_function(search_text.Text);
                search_text.Text = "";
            }
        }

        private void cart_button_Click(object sender, EventArgs e)
        {
            cart1.ShowDialog();
        }
    }
}
