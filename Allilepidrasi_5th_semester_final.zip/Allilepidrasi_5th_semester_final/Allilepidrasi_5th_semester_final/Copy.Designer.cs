﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Copy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.size_label = new System.Windows.Forms.Label();
            this.color_label = new System.Windows.Forms.Label();
            this.copies_label = new System.Windows.Forms.Label();
            this.A3_radio = new System.Windows.Forms.RadioButton();
            this.color_radio1 = new System.Windows.Forms.RadioButton();
            this.A4_radio = new System.Windows.Forms.RadioButton();
            this.paper_button = new System.Windows.Forms.Button();
            this.color_button = new System.Windows.Forms.Button();
            this.start_button = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.color_radio2 = new System.Windows.Forms.RadioButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.copies_text = new System.Windows.Forms.MaskedTextBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // size_label
            // 
            this.size_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.size_label.Location = new System.Drawing.Point(12, 20);
            this.size_label.Name = "size_label";
            this.size_label.Size = new System.Drawing.Size(141, 37);
            this.size_label.TabIndex = 0;
            this.size_label.Text = "PAPER SIZE";
            // 
            // color_label
            // 
            this.color_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color_label.Location = new System.Drawing.Point(12, 96);
            this.color_label.Name = "color_label";
            this.color_label.Size = new System.Drawing.Size(118, 31);
            this.color_label.TabIndex = 1;
            this.color_label.Text = "COLORED";
            // 
            // copies_label
            // 
            this.copies_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copies_label.Location = new System.Drawing.Point(12, 172);
            this.copies_label.Name = "copies_label";
            this.copies_label.Size = new System.Drawing.Size(100, 30);
            this.copies_label.TabIndex = 2;
            this.copies_label.Text = "COPIES";
            // 
            // A3_radio
            // 
            this.A3_radio.AutoSize = true;
            this.A3_radio.Checked = true;
            this.A3_radio.Location = new System.Drawing.Point(3, 3);
            this.A3_radio.Name = "A3_radio";
            this.A3_radio.Size = new System.Drawing.Size(38, 17);
            this.A3_radio.TabIndex = 3;
            this.A3_radio.TabStop = true;
            this.A3_radio.Text = "A3";
            this.A3_radio.UseVisualStyleBackColor = true;
            // 
            // color_radio1
            // 
            this.color_radio1.AutoSize = true;
            this.color_radio1.Location = new System.Drawing.Point(3, 3);
            this.color_radio1.Name = "color_radio1";
            this.color_radio1.Size = new System.Drawing.Size(46, 17);
            this.color_radio1.TabIndex = 4;
            this.color_radio1.TabStop = true;
            this.color_radio1.Text = "YES";
            this.color_radio1.UseVisualStyleBackColor = true;
            // 
            // A4_radio
            // 
            this.A4_radio.AutoSize = true;
            this.A4_radio.Location = new System.Drawing.Point(3, 26);
            this.A4_radio.Name = "A4_radio";
            this.A4_radio.Size = new System.Drawing.Size(38, 17);
            this.A4_radio.TabIndex = 5;
            this.A4_radio.TabStop = true;
            this.A4_radio.Text = "A4";
            this.A4_radio.UseVisualStyleBackColor = true;
            // 
            // paper_button
            // 
            this.paper_button.Location = new System.Drawing.Point(17, 229);
            this.paper_button.Name = "paper_button";
            this.paper_button.Size = new System.Drawing.Size(95, 23);
            this.paper_button.TabIndex = 7;
            this.paper_button.Text = "CHECK PAPER";
            this.paper_button.UseVisualStyleBackColor = true;
            this.paper_button.Click += new System.EventHandler(this.paper_button_Click);
            // 
            // color_button
            // 
            this.color_button.Location = new System.Drawing.Point(17, 262);
            this.color_button.Name = "color_button";
            this.color_button.Size = new System.Drawing.Size(95, 23);
            this.color_button.TabIndex = 8;
            this.color_button.Text = "CHECK COLOR";
            this.color_button.UseVisualStyleBackColor = true;
            this.color_button.Click += new System.EventHandler(this.color_button_Click);
            // 
            // start_button
            // 
            this.start_button.BackColor = System.Drawing.Color.Transparent;
            this.start_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.start_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.start_button.Location = new System.Drawing.Point(284, 246);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(112, 39);
            this.start_button.TabIndex = 9;
            this.start_button.Text = "START";
            this.start_button.UseVisualStyleBackColor = false;
            this.start_button.Click += new System.EventHandler(this.start_button_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.A3_radio);
            this.flowLayoutPanel1.Controls.Add(this.A4_radio);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(159, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(49, 51);
            this.flowLayoutPanel1.TabIndex = 11;
            // 
            // color_radio2
            // 
            this.color_radio2.AutoSize = true;
            this.color_radio2.Checked = true;
            this.color_radio2.Location = new System.Drawing.Point(3, 26);
            this.color_radio2.Name = "color_radio2";
            this.color_radio2.Size = new System.Drawing.Size(41, 17);
            this.color_radio2.TabIndex = 12;
            this.color_radio2.TabStop = true;
            this.color_radio2.Text = "NO";
            this.color_radio2.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.color_radio1);
            this.flowLayoutPanel2.Controls.Add(this.color_radio2);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(159, 87);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(57, 53);
            this.flowLayoutPanel2.TabIndex = 13;
            // 
            // copies_text
            // 
            this.copies_text.Location = new System.Drawing.Point(159, 178);
            this.copies_text.Mask = "0";
            this.copies_text.Name = "copies_text";
            this.copies_text.Size = new System.Drawing.Size(13, 20);
            this.copies_text.TabIndex = 14;
            this.copies_text.ValidatingType = typeof(int);
            // 
            // Copy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(408, 297);
            this.Controls.Add(this.copies_text);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.start_button);
            this.Controls.Add(this.color_button);
            this.Controls.Add(this.paper_button);
            this.Controls.Add(this.copies_label);
            this.Controls.Add(this.color_label);
            this.Controls.Add(this.size_label);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Copy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Copy";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label size_label;
        private System.Windows.Forms.Label color_label;
        private System.Windows.Forms.Label copies_label;
        private System.Windows.Forms.RadioButton A3_radio;
        private System.Windows.Forms.RadioButton color_radio1;
        private System.Windows.Forms.RadioButton A4_radio;
        private System.Windows.Forms.Button paper_button;
        private System.Windows.Forms.Button color_button;
        private System.Windows.Forms.Button start_button;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.RadioButton color_radio2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.MaskedTextBox copies_text;
    }
}