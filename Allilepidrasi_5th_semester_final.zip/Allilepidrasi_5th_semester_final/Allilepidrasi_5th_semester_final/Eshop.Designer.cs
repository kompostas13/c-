﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Eshop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Eshop));
            this.search_text = new System.Windows.Forms.TextBox();
            this.search_pic = new System.Windows.Forms.PictureBox();
            this.books_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.search_buy_label = new System.Windows.Forms.Label();
            this.cart_button = new System.Windows.Forms.Button();
            this.cart_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.search_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // search_text
            // 
            this.search_text.BackColor = System.Drawing.Color.Yellow;
            this.search_text.Location = new System.Drawing.Point(851, 41);
            this.search_text.Multiline = true;
            this.search_text.Name = "search_text";
            this.search_text.Size = new System.Drawing.Size(157, 30);
            this.search_text.TabIndex = 0;
            this.search_text.KeyDown += new System.Windows.Forms.KeyEventHandler(this.search_text_KeyDown);
            // 
            // search_pic
            // 
            this.search_pic.BackColor = System.Drawing.Color.Transparent;
            this.search_pic.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("search_pic.BackgroundImage")));
            this.search_pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.search_pic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.search_pic.Location = new System.Drawing.Point(1014, 41);
            this.search_pic.Name = "search_pic";
            this.search_pic.Size = new System.Drawing.Size(40, 30);
            this.search_pic.TabIndex = 1;
            this.search_pic.TabStop = false;
            this.search_pic.Click += new System.EventHandler(this.search_pic_Click);
            // 
            // books_label
            // 
            this.books_label.BackColor = System.Drawing.Color.Transparent;
            this.books_label.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.books_label.Location = new System.Drawing.Point(297, 74);
            this.books_label.Name = "books_label";
            this.books_label.Size = new System.Drawing.Size(549, 310);
            this.books_label.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(296, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(550, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "SOME OF OUR BOOKS:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // search_buy_label
            // 
            this.search_buy_label.BackColor = System.Drawing.Color.Transparent;
            this.search_buy_label.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_buy_label.ForeColor = System.Drawing.Color.OrangeRed;
            this.search_buy_label.Location = new System.Drawing.Point(852, 17);
            this.search_buy_label.Name = "search_buy_label";
            this.search_buy_label.Size = new System.Drawing.Size(156, 23);
            this.search_buy_label.TabIndex = 4;
            this.search_buy_label.Text = "SEARCH A BOOK";
            this.search_buy_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cart_button
            // 
            this.cart_button.BackColor = System.Drawing.Color.Yellow;
            this.cart_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cart_button.BackgroundImage")));
            this.cart_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cart_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_button.Location = new System.Drawing.Point(1040, 616);
            this.cart_button.Name = "cart_button";
            this.cart_button.Size = new System.Drawing.Size(66, 62);
            this.cart_button.TabIndex = 5;
            this.cart_button.UseVisualStyleBackColor = false;
            this.cart_button.Click += new System.EventHandler(this.cart_button_Click);
            // 
            // cart_label
            // 
            this.cart_label.BackColor = System.Drawing.Color.Transparent;
            this.cart_label.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_label.ForeColor = System.Drawing.Color.OrangeRed;
            this.cart_label.Location = new System.Drawing.Point(1036, 594);
            this.cart_label.Name = "cart_label";
            this.cart_label.Size = new System.Drawing.Size(83, 19);
            this.cart_label.TabIndex = 6;
            this.cart_label.Text = "GO TO CART";
            this.cart_label.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // Eshop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1118, 690);
            this.Controls.Add(this.cart_label);
            this.Controls.Add(this.cart_button);
            this.Controls.Add(this.search_buy_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.books_label);
            this.Controls.Add(this.search_pic);
            this.Controls.Add(this.search_text);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Eshop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Eshop";
            this.Load += new System.EventHandler(this.Eshop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.search_pic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox search_text;
        private System.Windows.Forms.PictureBox search_pic;
        private System.Windows.Forms.Label books_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label search_buy_label;
        private System.Windows.Forms.Button cart_button;
        private System.Windows.Forms.Label cart_label;
    }
}