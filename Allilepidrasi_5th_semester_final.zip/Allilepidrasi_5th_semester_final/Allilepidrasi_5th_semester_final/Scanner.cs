﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Scanner : Form
    {
        public Scanner()
        {
            InitializeComponent();
        }

        private void scan_button_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(1000);
            scan_button.BackColor = Color.LimeGreen;
            MessageBox.Show("SCAN AND DOWNLOAD COMPLETED");
            this.Close();
        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("PLACE YOUR DOCUMENT IN THE SCANNER , INSERT YOUR USB DRIVE , THEN PRESS THE BUTTON");
        }
    }
}
