﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Copy : Form
    {
        public Copy()
        {
            InitializeComponent();
        }

        private void paper_button_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(1000);
            paper_button.BackColor = Color.LimeGreen;
        }

        private void color_button_Click(object sender, EventArgs e)
        {
            System.Threading.Thread.Sleep(1000);
            color_button.BackColor = Color.LimeGreen;
        }

        private void start_button_Click(object sender, EventArgs e)
        {
            if ((paper_button.BackColor ==  Color.LimeGreen) & (color_button.BackColor == Color.LimeGreen) & (copies_text.Text != ""))
            {
                System.Threading.Thread.Sleep(3000);
                MessageBox.Show("COPYING COMPLETED");
                this.Close();
            }
            else
            {
                MessageBox.Show("DETERMINE NUMBER OF COPIES AND CHECK COLOR AND PAPER" , "ERROR!");
            }
        }
    }
}
