﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Allilepidrasi_5th_semester_final
{
    public partial class Office : Form
    {
        public Office()
        {
            InitializeComponent();
        }

        private void Office_Load(object sender, EventArgs e)
        {

        }

        private void pc_button_Click(object sender, EventArgs e)
        {
            Pc pc1 = new Pc();
            pc1.ShowDialog();
        }

        private void copy_button_Click(object sender, EventArgs e)
        {
            Copy copy1 = new Copy();
            copy1.ShowDialog();
        }

        private void scanner_button_Click(object sender, EventArgs e)
        {
            Scanner scanner1 = new Scanner();
            scanner1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void hELPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("PRESS THE COPY MACHINE / SCANNER / COMPUTER TO USE THEM" + Environment.NewLine + "PRESS BOTTOM RIGHT BUTTON TO EXIT");
        }
    }
}
