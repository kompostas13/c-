﻿namespace Allilepidrasi_5th_semester_final
{
    partial class Cart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cart));
            this.label1 = new System.Windows.Forms.Label();
            this.cart_l1 = new System.Windows.Forms.Label();
            this.cart_l2 = new System.Windows.Forms.Label();
            this.cart_l3 = new System.Windows.Forms.Label();
            this.cart_l4 = new System.Windows.Forms.Label();
            this.cart_l5 = new System.Windows.Forms.Label();
            this.cart_l6 = new System.Windows.Forms.Label();
            this.cart_l7 = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.card_label = new System.Windows.Forms.Label();
            this.address_label = new System.Windows.Forms.Label();
            this.card_mask = new System.Windows.Forms.MaskedTextBox();
            this.pay_button = new System.Windows.Forms.Button();
            this.pay_label = new System.Windows.Forms.Label();
            this.name_text = new System.Windows.Forms.TextBox();
            this.addr_text = new System.Windows.Forms.TextBox();
            this.sum_label = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hELPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(671, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "MY CART";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cart_l1
            // 
            this.cart_l1.BackColor = System.Drawing.Color.Transparent;
            this.cart_l1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l1.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l1.Location = new System.Drawing.Point(113, 65);
            this.cart_l1.Name = "cart_l1";
            this.cart_l1.Size = new System.Drawing.Size(570, 42);
            this.cart_l1.TabIndex = 1;
            this.cart_l1.Text = "YOUR CART IS EMPTY.";
            this.cart_l1.Click += new System.EventHandler(this.cart_l1_Click);
            // 
            // cart_l2
            // 
            this.cart_l2.BackColor = System.Drawing.Color.Transparent;
            this.cart_l2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l2.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l2.Location = new System.Drawing.Point(113, 104);
            this.cart_l2.Name = "cart_l2";
            this.cart_l2.Size = new System.Drawing.Size(570, 42);
            this.cart_l2.TabIndex = 2;
            // 
            // cart_l3
            // 
            this.cart_l3.BackColor = System.Drawing.Color.Transparent;
            this.cart_l3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l3.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l3.Location = new System.Drawing.Point(113, 144);
            this.cart_l3.Name = "cart_l3";
            this.cart_l3.Size = new System.Drawing.Size(570, 42);
            this.cart_l3.TabIndex = 3;
            // 
            // cart_l4
            // 
            this.cart_l4.BackColor = System.Drawing.Color.Transparent;
            this.cart_l4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l4.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l4.Location = new System.Drawing.Point(113, 182);
            this.cart_l4.Name = "cart_l4";
            this.cart_l4.Size = new System.Drawing.Size(570, 42);
            this.cart_l4.TabIndex = 4;
            // 
            // cart_l5
            // 
            this.cart_l5.BackColor = System.Drawing.Color.Transparent;
            this.cart_l5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l5.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l5.Location = new System.Drawing.Point(113, 221);
            this.cart_l5.Name = "cart_l5";
            this.cart_l5.Size = new System.Drawing.Size(570, 42);
            this.cart_l5.TabIndex = 5;
            // 
            // cart_l6
            // 
            this.cart_l6.BackColor = System.Drawing.Color.Transparent;
            this.cart_l6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l6.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l6.Location = new System.Drawing.Point(113, 263);
            this.cart_l6.Name = "cart_l6";
            this.cart_l6.Size = new System.Drawing.Size(570, 42);
            this.cart_l6.TabIndex = 6;
            // 
            // cart_l7
            // 
            this.cart_l7.BackColor = System.Drawing.Color.Transparent;
            this.cart_l7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cart_l7.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cart_l7.Location = new System.Drawing.Point(113, 305);
            this.cart_l7.Name = "cart_l7";
            this.cart_l7.Size = new System.Drawing.Size(570, 42);
            this.cart_l7.TabIndex = 7;
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Location = new System.Drawing.Point(117, 373);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(67, 13);
            this.name_label.TabIndex = 8;
            this.name_label.Text = "FULL NAME";
            // 
            // card_label
            // 
            this.card_label.AutoSize = true;
            this.card_label.Location = new System.Drawing.Point(117, 419);
            this.card_label.Name = "card_label";
            this.card_label.Size = new System.Drawing.Size(70, 13);
            this.card_label.TabIndex = 9;
            this.card_label.Text = "CARD CODE";
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Location = new System.Drawing.Point(117, 462);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(59, 13);
            this.address_label.TabIndex = 10;
            this.address_label.Text = "ADDRESS";
            // 
            // card_mask
            // 
            this.card_mask.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.card_mask.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.card_mask.Location = new System.Drawing.Point(190, 414);
            this.card_mask.Mask = "0000-0000-0000-0000";
            this.card_mask.Name = "card_mask";
            this.card_mask.Size = new System.Drawing.Size(154, 22);
            this.card_mask.TabIndex = 12;
            // 
            // pay_button
            // 
            this.pay_button.BackColor = System.Drawing.Color.Transparent;
            this.pay_button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pay_button.BackgroundImage")));
            this.pay_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pay_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pay_button.Location = new System.Drawing.Point(588, 503);
            this.pay_button.Name = "pay_button";
            this.pay_button.Size = new System.Drawing.Size(95, 65);
            this.pay_button.TabIndex = 14;
            this.pay_button.UseVisualStyleBackColor = false;
            this.pay_button.Click += new System.EventHandler(this.pay_button_Click);
            // 
            // pay_label
            // 
            this.pay_label.AutoSize = true;
            this.pay_label.Font = new System.Drawing.Font("Segoe Print", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pay_label.ForeColor = System.Drawing.Color.OrangeRed;
            this.pay_label.Location = new System.Drawing.Point(403, 521);
            this.pay_label.Name = "pay_label";
            this.pay_label.Size = new System.Drawing.Size(179, 26);
            this.pay_label.TabIndex = 15;
            this.pay_label.Text = "CONFIRM PURCHASE";
            // 
            // name_text
            // 
            this.name_text.Location = new System.Drawing.Point(190, 370);
            this.name_text.Name = "name_text";
            this.name_text.Size = new System.Drawing.Size(154, 20);
            this.name_text.TabIndex = 16;
            // 
            // addr_text
            // 
            this.addr_text.Location = new System.Drawing.Point(190, 459);
            this.addr_text.Name = "addr_text";
            this.addr_text.Size = new System.Drawing.Size(154, 20);
            this.addr_text.TabIndex = 17;
            this.addr_text.TextChanged += new System.EventHandler(this.addr_text_TextChanged);
            // 
            // sum_label
            // 
            this.sum_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sum_label.Location = new System.Drawing.Point(499, 459);
            this.sum_label.Name = "sum_label";
            this.sum_label.Size = new System.Drawing.Size(184, 41);
            this.sum_label.TabIndex = 19;
            this.sum_label.Text = "SUM: 0 $";
            this.sum_label.Click += new System.EventHandler(this.label2_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hELPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(695, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hELPToolStripMenuItem
            // 
            this.hELPToolStripMenuItem.Name = "hELPToolStripMenuItem";
            this.hELPToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.hELPToolStripMenuItem.Text = "HELP";
            this.hELPToolStripMenuItem.Click += new System.EventHandler(this.hELPToolStripMenuItem_Click);
            // 
            // Cart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(695, 572);
            this.Controls.Add(this.sum_label);
            this.Controls.Add(this.addr_text);
            this.Controls.Add(this.name_text);
            this.Controls.Add(this.pay_label);
            this.Controls.Add(this.pay_button);
            this.Controls.Add(this.card_mask);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.card_label);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.cart_l7);
            this.Controls.Add(this.cart_l6);
            this.Controls.Add(this.cart_l5);
            this.Controls.Add(this.cart_l4);
            this.Controls.Add(this.cart_l3);
            this.Controls.Add(this.cart_l2);
            this.Controls.Add(this.cart_l1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Cart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cart";
            this.Load += new System.EventHandler(this.Cart_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label cart_l1;
        private System.Windows.Forms.Label cart_l2;
        private System.Windows.Forms.Label cart_l3;
        private System.Windows.Forms.Label cart_l4;
        private System.Windows.Forms.Label cart_l5;
        private System.Windows.Forms.Label cart_l6;
        private System.Windows.Forms.Label cart_l7;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label card_label;
        private System.Windows.Forms.Label address_label;
        private System.Windows.Forms.MaskedTextBox card_mask;
        private System.Windows.Forms.Button pay_button;
        private System.Windows.Forms.Label pay_label;
        private System.Windows.Forms.TextBox name_text;
        private System.Windows.Forms.TextBox addr_text;
        private System.Windows.Forms.Label sum_label;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hELPToolStripMenuItem;
    }
}